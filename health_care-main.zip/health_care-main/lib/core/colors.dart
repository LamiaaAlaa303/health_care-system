
import 'package:flutter/material.dart';

//Color defaultColor=const Color(0xff335288);
Color defaultColor=eminence;
Color paleRobinEggBlue=const Color(0xff93d8d5);
Color middleBlueGreen=const Color(0xff8cd3d7);
Color middleBlue=const Color(0xff75ccd3);
Color eminence=const Color(0xff673f88);
Color violet=const Color(0xff9c318a);
Color oldSilver=const Color(0xff858585);
Color  metallicBlue=const Color(0xff395186);
Color  secondColor=violet;
Color  ceil=const Color(0xff98a7c1);
Color  brightGray=const Color(0xffefefef);
Color  spanishGray=const Color(0xff979797);
Color  lotion=const Color(0xfffafafa);
Color  green=const Color(0xff67a67e);
Color  wildBlueYonder=const Color(0xffabb6cf);

Color  startProfileHeaderColor=const Color(0xffe7ebef);
Color  midProfileHeaderColor=violet;
Color  endProfileHeaderColor=eminence;

/*Color  startProfileHeaderColor=const Color(0xffe7ebef);
Color  midProfileHeaderColor=const Color(0xff9caac7);
Color  endProfileHeaderColor=const Color(0xff486494);*/


/*Color raisinBlack=const Color(0xff252525);
Color outerSpace=const Color(0xff444444);
Color lotion=const Color(0xfffafafa);
Color chineseWhite=const Color(0xffe0e0e0);
Color dimGray=const Color(0xff696969);
Color spanishGray=const Color(0xff999999);
Color davyIsGrey=const Color(0xff565656);
const gainsBoro = Color(0xffdfdede);
const platinum = Color(0xffe8e7e7);
const pewterBlue = Color(0xff7cb5b4);
const brightGray = Color(0xffe5f4f3);
const cultured = Color(0xfff8f8f8);
const taupeGray = Color(0xff898989);
const antiFlashWhite = Color(0xffe7f7f2);
const argent = Color(0xffc1bfbf);
const offWhite = Color.fromRGBO(248, 248, 248, 1);
Color darkSilver=const Color(0xff707070);
Color mikadoYellow=const Color(0xfffec008);
Color lightSilver=const Color(0xffd6d6d6);
Color silverSand=const Color(0xffC4C4C4);*/
