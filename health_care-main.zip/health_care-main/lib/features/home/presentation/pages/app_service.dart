
class AppService{
  final String image, title;
  final void Function() onTap;

  const AppService(this.image, this.title, this.onTap);
}